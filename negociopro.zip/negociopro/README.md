# ⚡ NegociPro v3.0

**ERP SaaS mobile-first para minimarkets en Latinoamérica**

> Sistema de gestión completo: ventas, inventario, fiados, contactos, caja chica, notificaciones y más.

---

## 🚀 Stack

| Tecnología | Versión | Uso |
|---|---|---|
| Next.js | 15 | Framework principal |
| React | 19 | UI |
| Framer Motion | 11 | Animaciones |
| Anthropic Claude | claude-sonnet-4 | IA para análisis de imágenes |

---

## 📱 Características

- **🛒 POS completo** — Carrito interactivo, múltiples métodos de pago, fiado con selector de cliente
- **📦 Inventario** — CRUD completo, alertas de stock crítico, subida de imágenes de proveedor con IA
- **💸 Libro de Fiados** — Registro, cobro, notificaciones completas
- **👥 Contactos** — Clientes, proveedores, empleados con historial y sistema de puntos
- **💸 Caja Chica** — Gastos diarios con +/- por ítem, tipos de gastos personalizables
- **🔒 Cierre de Caja** — Conteo de billetes, cuadre automático, historial
- **🔔 Notificaciones** — Smart sort, detalle expandible, todas las acciones notificadas
- **📊 Reportes** — Exportar Excel, PDF, backup JSON, WhatsApp, Gmail
- **⚙️ Configuración** — Empleados, Telegram Bot, seguridad con PIN

---

## 🛠️ Instalación local

```bash
# 1. Clonar el repo
git clone https://github.com/yonadafo19-bot/negociopro.git
cd negociopro

# 2. Instalar dependencias
npm install

# 3. Configurar variables de entorno
cp .env.example .env.local
# Edita .env.local con tu API key de Anthropic

# 4. Correr en desarrollo
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

---

## 🌐 Deploy en Vercel (gratis)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yonadafo19-bot/negociopro)

1. Haz clic en el botón de arriba
2. Conecta tu cuenta de GitHub
3. Agrega la variable de entorno `NEXT_PUBLIC_ANTHROPIC_API_KEY`
4. ¡Deploy automático en segundos!

---

## 📂 Estructura del proyecto

```
negociopro/
├── src/
│   ├── app/
│   │   ├── layout.jsx      # Layout raíz de Next.js
│   │   ├── page.jsx        # Página principal → renderiza App
│   │   └── globals.css     # Estilos globales
│   └── components/
│       └── AppMockup.jsx   # App completa (~7800 líneas)
├── public/                 # Assets estáticos
├── package.json
├── next.config.js
├── vercel.json
├── jsconfig.json
├── .gitignore
├── .env.example
└── README.md
```

---

## 🎨 Diseño

- **Sistema:** Neumorfismo dark/light
- **Color accent:** Amber `#F0B429` (personalizable)
- **Fuentes:** Bricolage Grotesque · DM Sans · JetBrains Mono
- **Mobile-first:** Contenedor de 480px optimizado para teléfono

---

## 📄 Licencia

Proyecto privado — © 2026 NegociPro. Todos los derechos reservados.
